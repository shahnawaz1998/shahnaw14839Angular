export interface CategoryOne {
    tid:number
    cid:number
     cname1:string
    tdescription:string

}
