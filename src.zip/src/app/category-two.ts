export interface CategoryTwo {
    tid:number
    cid:number
    cname2:string
    tdescription:string
}
