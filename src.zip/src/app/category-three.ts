export interface CategoryThree {
    tid:number
    cid:number
    cname3:string
    tdescription:string
}
