import { Component, OnInit } from '@angular/core';
import { CategoryThree } from '../category-three';
import { CategoryTwo } from '../category-two';
import { CategoryappserviceService } from '../categoryappservice.service';
import { CategoryOne } from '../categoryOne';

@Component({
  selector: 'app-task-manager',
  templateUrl: './task-manager.component.html',
  styleUrls: ['./task-manager.component.css']
})
export class TaskManagerComponent implements OnInit {
// cid:number

// textarea1:string
// textarea2:string
// textarea3:string
isViewMode1:boolean
isViewMode2:boolean
isViewMode3:boolean
textAreaList1:any =[];
textAreaList2:any =[];
textAreaList3:any =[];
categoryOne:CategoryOne[]
categoryTwo: CategoryTwo[]
categoryThree: CategoryThree[]


  constructor(private tasksvc:CategoryappserviceService) {
    // this.cid= 101
    
    // this.textarea1=""
    // this.textarea2=""
    // this.textarea3=""
    this.isViewMode1=true
    this.isViewMode2=true
    this.isViewMode3=true

    this.categoryOne =  [
      {tid:1001,cid:101,cname1:"must dos",tdescription:"test"},
      
    ]
    this.categoryTwo = [
      {tid:1002,cid:102,cname2:"quick hits",tdescription:"test2"},
    ]

    this.categoryThree = [
      {tid:1003,cid:102,cname3:"nice to have",tdescription:"test2"},
    ]
   }  
   

  ngOnInit(): void {
  }
  toggleModeforCategoryOne(){
    this.isViewMode1=!this.isViewMode1
  }

  toggleModeforCategoryTwo(){
    this.isViewMode2=!this.isViewMode2
  }

  toggleModeforCategoryThree(){
    this.isViewMode3=!this.isViewMode3
  }

addTextArea1(){
  this.textAreaList1.push('text-area' + (this.textAreaList1.length+1));

}
  removeTextArea1(index:any){
    this.textAreaList1.splice(index,1)
  }
  addTextArea2(){
    this.textAreaList2.push('text-area' + (this.textAreaList2.length+1));
  
  }
    removeTextArea2(index:any){
      this.textAreaList2.splice(index,1)
    }
    addTextArea3(){
      this.textAreaList3.push('text-area' + (this.textAreaList3.length+1));
    
    }
      removeTextArea3(index:any){
        this.textAreaList3.splice(index,1)
      }

      registerTask(newCategory:CategoryOne){
  
      this.tasksvc.registerTaskList(newCategory.cid,newCategory).subscribe(
        response=>{
          console.log(response)
          // fetch projects from server
          this.tasksvc.getTaskByTid(newCategory.cid).subscribe(
            response=>{
              console.log(response)
            },
            error=>{console.log(error)}
          )
        },
        error=>{console.log(error)}
      )
      }
    }


